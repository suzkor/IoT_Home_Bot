# IoT_Home_Bot

Raspberry Pi -(温湿度データ)-> AWS IoT Core -> DynamoDB 
LINE Bot <-> Lambda <- DynamoDB

って感じ